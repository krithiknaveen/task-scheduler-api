package com.think41.repository;

public interface TaskRepository extends JpaRepository<Task,Long> {
	
	Optional<Task> findByTaskStrId(String taskStrId);
	@Query("SEELECT t FROM Task t where t.status = 'pending' ORDER BY t.estimatedTimeMinutes ASC, t.submittedAt ASC")
	Optional<Task>
	Optional<Task>findTopPendingTaskByPriority();
	
	List<Task> findByStatus(String status,Pageable);
	
	
	
	

}
