package com.think41.service;

import java.util.List;
import java.util.Map;

import com.think41.repository.TaskRepository;

public class TaskService {
	
	public final TaskRepository taskRepository;

	public TaskService(TaskRepository taskRepository) {
		super();
		// TODO Auto-generated constructor stub
		this.taskRepository = taskRepository;
	}
	public static final Map<String,List<String>> VALID_TRANSACTIONS = Map.of("pending",
			List.of("processing"),"processing",
			List.of("completed"),"completed",
			List.of());
	
	public Task createTask(Task task) {
        if (task.getEstimatedTimeMinutes() <= 0) {
            throw new IllegalArgumentException("Estimated time must be > 0");
        }
        task.setStatus("pending");
        return taskRepository.save(task);
    }

    public Task getTask(String taskStrId) {
        return taskRepository.findByTaskStrId(taskStrId)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found"));
    }

    public Task updateTaskStatus(String taskStrId, String newStatus) {
        Task task = getTask(taskStrId);
        String current = task.getStatus().toLowerCase();
        String target = newStatus.toLowerCase();

        if (!VALID_TRANSITIONS.getOrDefault(current, List.of()).contains(target)) {
            throw new InvalidStatusTransitionException("Cannot change status from " + current + " to " + target);
        }

        task.setStatus(target);
        return taskRepository.save(task);
    }

    public Task getNextPendingTask() {
        return taskRepository.findTopPendingTaskByPriority()
                .orElseThrow(() -> new ResourceNotFoundException("No pending tasks found"));
    }

    public List<Task> getPendingTasks(String sortBy, String order, int limit) {
        Sort.Direction direction = order.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        String sortField = mapToEntityField(sortBy);
        Pageable pageable = PageRequest.of(0, limit, Sort.by(direction, sortField));
        return taskRepository.findByStatus("pending", pageable);
    }

    private String mapToEntityField(String input) {
        return switch (input.toLowerCase()) {
            case "estimated_time_minutes" -> "estimatedTimeMinutes";
            case "submitted_at" -> "submittedAt";
            default -> "submittedAt";
        };
    }


}
