package com.think41;
@Entity
@Table(name = "tasks")
public class Main{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(unique = true)
	private String taskStrId;
	
	private String description;
	
	private int estimatedTimeMinutes;
	
	private String status = "pending";
	
	private Timestamp submittedAt;
	
	@PrePersist
	protected void onCreate() {
		this.submittedAt = new Timestamp(System.currentTimeMillis());
	}
	
}