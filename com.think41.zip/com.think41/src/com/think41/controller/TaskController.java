package com.think41.controller;
@RestController
@RequestMapping("/tasks")
public class TaskController {
	
	private final TaskService taskService;

    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createTask(@RequestBody Task task) {
        Task created = taskService.createTask(task);
        Map<String, Object> response = Map.of(
                "internal_db_id", created.getId(),
                "task_str_id", created.getTaskStrId(),
                "status", created.getStatus()
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{taskStrId}")
    public ResponseEntity<Task> getTask(@PathVariable String taskStrId) {
        return ResponseEntity.ok(taskService.getTask(taskStrId));
    }

    @PutMapping("/{taskStrId}/status")
    public ResponseEntity<Task> updateStatus(@PathVariable String taskStrId,
                                             @RequestBody Map<String, String> request) {
        String newStatus = request.get("new_status");
        return ResponseEntity.ok(taskService.updateTaskStatus(taskStrId, newStatus));
    }

    @GetMapping("/next-to-process")
    public ResponseEntity<Task> getNextToProcess() {
        return ResponseEntity.ok(taskService.getNextPendingTask());
    }

    @GetMapping("/pending")
    public ResponseEntity<List<Task>> listPendingTasks(
            @RequestParam(defaultValue = "estimated_time_minutes") String sort_by,
            @RequestParam(defaultValue = "asc") String order,
            @RequestParam(defaultValue = "10") int limit) {

        List<Task> tasks = taskService.getPendingTasks(sort_by, order, limit);
        return ResponseEntity.ok(tasks);
    }

}
